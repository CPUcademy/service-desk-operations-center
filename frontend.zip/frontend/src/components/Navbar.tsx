import { NavLink } from "react-router";
import "./Navbar.css";

function Navbar() {

  const isAdmin = true;

  return (
    <div>
      <aside className="navbar">
        <nav className="navbar-links">
          {isAdmin && (
            <NavLink to="/dashboard" className={({ isActive }) => isActive ? "navbar-link active" : "navbar-link"}>
              Dashboard
            </NavLink>
          )}

          <NavLink to="/chat" className={({ isActive }) => isActive ? "navbar-link active" : "navbar-link"}>
            Chat
          </NavLink>

          <NavLink to="/tickets" className={({ isActive }) => isActive ? "navbar-link active" : "navbar-link"}>
            Tickets
          </NavLink>

          {isAdmin && (
            <NavLink to="/admin" className={({ isActive }) => isActive ? "navbar-link active" : "navbar-link"}>
              Admin
            </NavLink>
          )}
        </nav>

        <div className="navbar-profile">
          <NavLink to="/profile" className="profile-link">

            <div className="profile-avatar">SP</div>

            <div>
              <p>Szymon Perlicki</p>
              <span>{isAdmin ? "ADMINISTRATOR" : "USER"}</span>
            </div>

          </NavLink>
        </div>
      </aside>
    </div>
  )
}

export default Navbar